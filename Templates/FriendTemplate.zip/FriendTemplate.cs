﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FriendTimes.Friends.$safeitemname$
{
    public sealed class $safeitemname$ : Friend
    {
        //need this so there's only one instance of you
        private static readonly Lazy<$safeitemname$>
            lazy =
            new Lazy<$safeitemname$>
                (() => new $safeitemname$());

        public static $safeitemname$ Instance { get { return lazy.Value; } }


        /// <summary>
        /// Constructor for your class
        /// </summary>
        public $safeitemname$()
        {
  
        }

        
    }
}
